-- Listing 1.1.sql
-- Meldung der SQL-Konsole beim Ausführen einer Anweisung
Statement ' SELECT * FROM m_cs_tables' 
successfully executed in 9 ms 90 µs (server processing time: 6 ms 
985 µs)
Fetched 302 row(s) in 27 ms 160 µs (server processing time: 15 ms 
984 µs)

