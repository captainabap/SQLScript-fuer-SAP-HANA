-- Listing 8.15.sql
-- Beispiel für eine skalare AMDP-Funktion

CLASS zjb_bw_tools_amdp DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.
    INTERFACES if_amdp_marker_hdb.
    METHODS replace_unallowed_characters
      IMPORTING VALUE(iv_input)  TYPE rschavl60
      RETURNING VALUE(rv_output) TYPE rschavl60.
ENDCLASS.

CLASS zjb_bw_tools_amdp IMPLEMENTATION.

  METHOD replace_unallowed_characters BY DATABASE FUNCTION 
                                     FOR HDB LANGUAGE SQLSCRIPT 
                                     OPTIONS READ-ONLY.

    rv_output = CASE WHEN LEFT( :iv_input, 1 ) = '!'
                       THEN replace( iv_input ,'!' , '$')
                     WHEN :iv_input = '#'
                       THEN ''
                     ELSE :iv_input
                END;

    rv_output = replace_regexpr( '[[:cntrl:]]' 
                                     IN :rv_output WITH '' );
    rv_output = replace( :rv_output, nchar( '0130'), '');
  ENDMETHOD.
ENDCLASS.
