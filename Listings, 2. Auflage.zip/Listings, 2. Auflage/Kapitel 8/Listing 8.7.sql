-- Listing 8.7.sql
-- Grundgerüst der Definition einer CDS-Tabellenfunktion

METHOD <Methodenname> BY DATABASE FUNCTION
                      FOR HDB LANGUAGE SQLSCRIPT
                      OPTIONS READ-ONLY
                      [USING <Verwendungen>].
  <SQLScript-Code>
ENDMETHOD.
