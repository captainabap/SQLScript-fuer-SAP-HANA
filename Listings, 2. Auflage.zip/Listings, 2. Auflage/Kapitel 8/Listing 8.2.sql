-- Listing 8.2.sql
-- Schlüsselwörter bei der Implementierung einer AMDP-Methode

1  METHOD get_countries
2     BY DATABASE PROCEDURE FOR HDB 
3     LANGUAGE SQLSCRIPT
4     OPTIONS READ-ONLY
5     USING t005t.
6
7    <SQLScript-Code>
8  ENDMETHOD.
