-- Listing 8.3.sql
-- Quellcode der Prozedur ZCL_AMDP_DEMO=>GET_COUNTRIES

CREATE PROCEDURE
  "ZCL_AMDP_DEMO=>GET_COUNTRIES"
(
  IN   "IV_LANGU" NVARCHAR (000001),
  OUT  "EV_SUBRC" INTEGER,
  IN   "CT_COUNTRY__IN__" "ZCL_AMDP_DEMO=>GET_COUNTRIES=>P00000#ttyp",
  OUT  "CT_COUNTRY" "ZCL_AMDP_DEMO=>GET_COUNTRIES=>P00000#ttyp"
)
LANGUAGE sqlscript  SQL SECURITY INVOKER
AS BEGIN
"CT_COUNTRY" = select * from  :CT_COUNTRY__IN__ ;
BEGIN
    lt_countries = SELECT land1 FROM :CT_COUNTRY;
    et_country = SELECT t5.*
                 FROM "ZCL_AMDP_DEMO=>T005T#covw" AS t5
                 INNER JOIN :LT_COUNTRIES AS countries
                 ON t5.land1 = countries.land1
                 WHERE t5.spras = :IV_LANGU;

    SELECT CASE
              WHEN COUNT(*) > 0
              THEN 0
              ELSE 4
              END AS subrc
          INTO ev_subrc
          FROM :CT_COUNTRY;
END;

END;
