-- Listing 7.11.sql
-- Beispiel für die Nutzung einer Sequenz

SELECT * FROM rechnungen( 'USD' ); 
SELECT * FROM rechnungen( iv_waehrung=>'USD' );
CREATE SEQUENCE <Sequenzname> <Parameter>
CREATE SEQUENCE countdown INCREMENT BY-1
                          MAXVALUE 10
                          MINVALUE 0
                          CYCLE;
DO BEGIN
   DECLARE lv_counter INT;
   DECLARE lv_tmp INT;
   DECLARE la_array INT ARRAY;

   FOR lv_counter IN 1..100 DO
      SELECT countdown.nextval
         INTO lv_tmp
         FROM dummy;
      la_array[:lv_counter] = lv_tmp;
   END FOR;
   lt_output = UNNEST(:la_array);
   SELECT *
      FROM :LT_OUTPUT;
END;
