-- Listing 7.1.sql
-- Spaltendefinition

CREATE TABLE status (id INT , 
                     text NVARCHAR(30) );
<Spaltenname>
   <Datentyp>
   [DEFAULT <Standardwert>]
   [<Einschränkung>]
