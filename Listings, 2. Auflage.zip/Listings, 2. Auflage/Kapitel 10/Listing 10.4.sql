-- Listing 10.4.sql
-- Redundante Kommentare sind ohne Mehrwert

--Deklaration einer Variable lv_a vom Typ Integer:
DECLARE lv_a INT; 
--Zuweisung des Wertes 0 zu der Variable lv_a
lv_a = 0;
