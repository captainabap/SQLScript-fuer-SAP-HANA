-- Listing 10.6.sql
-- Beispiel für Kurzformen in SQLScript

SELECT * 
FROM farben groessen;

SELECT * 
FROM farben, groessen;
