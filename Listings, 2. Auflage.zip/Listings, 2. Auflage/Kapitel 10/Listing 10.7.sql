-- Listing 10.7.sql
-- Das gleiche Beispiel ohne Kurzform

SELECT * 
FROM farben AS groessen;

SELECT * 
FROM farben CROSS JOIN groessen;
