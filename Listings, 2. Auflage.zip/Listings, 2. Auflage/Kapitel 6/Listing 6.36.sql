-- Listing 6.36.sql
-- Syntax der DELETE-Anweisung

DELETE FROM <DB-Tabelle> 
    WHERE CURRENT OF <Cursor>
