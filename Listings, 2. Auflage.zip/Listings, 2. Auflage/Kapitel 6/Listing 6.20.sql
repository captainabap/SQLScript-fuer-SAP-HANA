-- Listing 6.20.sql
-- Syntax der IF-Anweisung

IF <Bedingung_1> THEN <Block_1>
[ELSEIF <Bedingung_2> THEN <Block_2>]
...
[ELSE <Block_N>]
END IF;
