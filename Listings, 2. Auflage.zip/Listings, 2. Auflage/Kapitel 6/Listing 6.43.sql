-- Listing 6.43.sql
-- Syntax einer autonomen Transaktion

BEGIN AUTONOMOUS TRANSACTION
...
END;
