-- Listing 6.14.sql
-- Syntax des SEARCH-Operators

:<Tabellenvariabe>.SEARCH((<Spaltenliste>),
                          (<Werteliste>), 
                          [<Startindex>]); 
