-- Listing 6.12.sql
-- Zeilenweises Aktualisieren einer Tabellenvariablen mit UPDATE und indexbasiertem Zugriff

:<Tabellenvariable>[.<Spaltenliste>].UPDATE((<Werteliste>), 
                                             <Position>);
<Tabellenvariable>[.<Spaltenliste>].[<Position>] = 
                                             (<Werteliste>);
DO BEGIN 
   DECLARE lt_tmp TABLE(text NVARCHAR(100));

-- Zeilenweiser Aufbau der Tabelle
   :lt_tmp.INSERT(('Einfügen 1'), 1);
   :lt_tmp.INSERT(('Einfügen 2'), 2);
   :lt_tmp.INSERT(('Einfügen 3'), 3);
   
-- Update der Zeilen    
   :lt_tmp.UPDATE(('Aktualisieren 2'),2);
   :lt_tmp.UPDATE(('Aktualisieren 4'),4);
   
-- Update mit indexbasiertem Zugriff   
   lt_tmp[6] = ('Aktualisieren 6');
END;
