-- Listing 6.32.sql
-- FOR-Schleife über Cursor

DECLARE CURSOR <Cursorname> (<Parameterdefinition>) 
   FOR <SELECT-Abfrage>;
FOR <Zeile> AS <Cursorname>[(<Parameter>)] 
DO
<Block>
END FOR; 
