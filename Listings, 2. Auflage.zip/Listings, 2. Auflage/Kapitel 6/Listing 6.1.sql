-- Listing 6.1.sql
-- Definition einer lokalen skalaren Variable

DELETE FROM <Tabellenname> [WHERE <Bedingungen>]
DECLARE <Variablenname> 
   [CONSTANT] 
   <Datentyp> 
   [NOT NULL] 
   [ '=' | DEFAULT) <Initialwert>;
