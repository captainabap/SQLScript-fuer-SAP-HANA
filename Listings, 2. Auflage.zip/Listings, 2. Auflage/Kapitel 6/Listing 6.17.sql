-- Listing 6.17.sql
-- Verwendung von Sessionvariablen

SET <Variablenname> = <Wert>;
DO BEGIN
SET 'TESTVARIABLE' = 'TESTWERT';
SELECT session_context( 'TESTVARIABLE' ) FROM dummy;
END;
