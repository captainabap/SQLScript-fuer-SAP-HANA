-- Listing 6.52.sql
-- Beispiele für das Auslösen von benutzerdefinierten Ausnahmen

SELECT * FROM m_error_codes ORDER BY code;
DECLARE <Fehlername> CONDITION [FOR SQL_ERROR_CODE <Fehlercode>];
DECLARE unbekannte_aufgabe CONDITION; 
DECLARE Division_durch_0 CONDITION SQL_ERROR_CODE 304;
--Nur mit Fehlercode und Text:
SIGNAL SQL_ERROR_CODE 10000 SET MESSAGE_TEXT = 'Mein Fehler';

--oder mit definiertem Fehlername und Text:
DECLARE my_error CONDITION FOR SQL_ERROR_CODE 10000;
... 
SIGNAL my_error SET MESSAGE_TEXT = 'Mein Fehler'; 

--oder auch ohne Fehlercode und Text: 
DECLARE my_error CONDITION;
... 
SIGNAL my_error;
