-- Listing 6.16.sql
-- Suche und Schleife mit einer sortierten Tabelle

DECLARE lt_dml TABLE (vorname  NVARCHAR(30),
                      nachname NVARCHAR(30));
INSERT INTO :lt_dml (SELECT vorname, 
                            nachname
                       FROM benutzer);
SELECT * 
  FROM :lt_dml;
lt_normal = SELECT * FROM :lt_dml;
DECLARE <Tabellenvariable> TABLE(<Spaltendefinition>) 
                           SEARCH KEY(<Suchschlüssel>)
DO BEGIN
  DECLARE lv_index INTEGER;
  DECLARE lt_task TABLE (id INTEGER,
                         bearbeiter INTEGER,
                         titel NVARCHAR(130))
                  SEARCH KEY (bearbeiter);
                    
  lt_task = SELECT id, 
                   bearbeiter, 
                   titel 
              FROM aufgaben;
              
--Erste Zeile mit SEARCH finden            
  lv_index = :lt_task.SEARCH(bearbeiter, 4);
  
--Schleife über die Tabelle, solange die Bedingung erfüllt ist
  WHILE :lv_index > 0 
  AND :lt_task.bearbeiter[:lv_index] = 4
    DO
      if :lt_task.bearbeiter[:lv_index] = 4 THEN
      lt_task.titel[:lv_index] = '>>' 
                                 || :lt_task.titel[:lv_index];
       end if;
      lv_index = :lv_index + 1;
  END WHILE;              
                         
  SELECT * 
    FROM :lt_task;                       
END; 
