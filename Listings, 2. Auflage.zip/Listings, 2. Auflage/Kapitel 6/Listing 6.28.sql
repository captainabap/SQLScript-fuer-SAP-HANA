-- Listing 6.28.sql
-- Syntax der WHILE-Schleife

WHILE <Bedingung> DO
<Block>
END WHILE;
