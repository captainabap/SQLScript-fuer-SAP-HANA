-- Listing 6.35.sql
-- Syntax der UPDATE-Anweisung 

DECLARE CURSOR <Cursorname> (<Parameterdefinition>) 
   FOR <SELECT-Abfrage> FOR UPDATE [OF <Spaltenliste>];
UPDATE <DB-Tabelle> 
    SET <Set-Klausel>
    WHERE CURRENT OF <Cursor>
