-- Listing 6.51.sql
-- Verwendung von Literalen in dynamischem Code

DO BEGIN
  DECLARE lv_where NVARCHAR(1000) = '';
  lv_where = 'titel LIKE (''v%'') '; 
  lt_tmp = SELECT * FROM aufgaben;
  lt_tmp = apply_filter(:lt_tmp, :lv_where);
  
  SELECT * FROM :lt_tmp;

END
