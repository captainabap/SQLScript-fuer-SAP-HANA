-- Listing 6.21.sql
-- Prädikate mit Unterabfragen 

  IF EXISTS (SELECT id 
               FROM aufgaben
              WHERE status = 2
                AND faelligkeit < CURRENT_DATE)
  THEN  
    <do something>  
  ELSEIF :lv_status IN (SELECT id
                          FROM status
                         WHERE is_final = true)
  THEN  
    <do something else>  
  END IF;
