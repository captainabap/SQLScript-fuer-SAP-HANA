-- Listing 6.26.sql
-- Syntax der FOR-Schleife

FOR <Variable> IN [REVERSE] <Ausgangswert>..<Endwert> DO
   <Block>
END FOR;
