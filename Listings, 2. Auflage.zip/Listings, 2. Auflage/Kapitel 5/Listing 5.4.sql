-- Listing 5.4.sql
-- Syntax der INSERT-Anweisung für mehrere Datensätze mit Spaltenreihenfolge

INSERT INTO <Tabellenname>
         <Spaltenreihenfolge>
         <Abfrage>;
