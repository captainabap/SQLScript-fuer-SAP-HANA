-- Listing 5.10.sql
-- Syntax der Anweisung MERGE INTO

   MERGE INTO <Zieltabelle>  [AS <Zielalias>]
        USING <Quelltabelle> [AS <Quellalias>]
        ON (<Bedingungen>)
        [WHEN MATCHED THEN 
             UPDATE SET <Spaltenaktualisierungen>]
        [WHEN NOT MATCHED THEN 
             INSERT [<Spaltenliste>] VALUES( <Werte>)];
