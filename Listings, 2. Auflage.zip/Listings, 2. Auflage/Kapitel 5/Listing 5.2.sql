-- Listing 5.2.sql
-- Beispiel für das Einfügen mit Spaltenreihenfolge

INSERT INTO <Tabellenname> VALUES (<Spaltenwerte>, ...);
INSERT INTO tabelle_1 VALUES (1, 1, 'Erste Zeile'); 
INSERT INTO tabelle_1 VALUES (1, 2, 'Datum:'||CURRENT_DATE );
INSERT INTO <Tabellenname> <Spaltenreihenfolge> 
       VALUES (<Spaltenwerte>)
INSERT INTO tabelle_1 (key2, wert1) 
       VALUES ( 2, 'Defaultwert');
INSERT INTO tabelle_1 (wert1, key1, key2) 
       VALUES ('Vertauschte Spalten', 2, 3);
