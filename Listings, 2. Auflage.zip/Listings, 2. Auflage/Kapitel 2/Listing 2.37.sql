-- Listing 2.37.sql
-- Nutzung der Konstanten aus dem Listing 2.36
SELECT * 
  FROM aufgaben
 WHERE id < const:cv_max
   AND id > const:cv_min;
