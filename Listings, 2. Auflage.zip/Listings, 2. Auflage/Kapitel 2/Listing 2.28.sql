-- Listing 2.28.sql
-- Rekursive Berechnung von Fibonacci-Zahlen
CREATE PROCEDURE fibonacci(IN iv_value INT,
                           OUT rv_result INT)
AS BEGIN
  DECLARE lv_tmp INT;
  
  IF iv_value IN (1, 2)
    THEN rv_result = 1;
  ELSE
    fibonacci( iv_value - 1 , rv_result );
    fibonacci( iv_value - 2 , lv_tmp );
    rv_result = rv_result + lv_tmp;
  END IF;
END; 

CALL fibonacci(20, ?);
