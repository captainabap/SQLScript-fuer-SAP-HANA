-- Listing 2.18.sql
-- Bestandteile der Anweisung CREATE PROCEDURE
CREATE [OR REPLACE] PROCEDURE <Prozedurname> 
[(<Parameterliste>)] 
[LANGUAGE {SQLSCRIPT|RLANG} ] 
[SQL SECURITY {DEFINER|INVOKER} ] 
[DEFAULT SCHEMA Defaultschema] 
[READS SQL DATA ] 
[WITH ENCRYPTION] 
AS 
BEGIN [SEQUENTIAL EXECUTION]
<Quellcode> 
END
