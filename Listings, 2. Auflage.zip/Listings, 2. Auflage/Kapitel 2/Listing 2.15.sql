-- Listing 2.15.sql
-- Syntax von Blöcken
BEGIN
   [<Deklarationen>]
   [<Ausnahmebehandler>]
   [<Anweisungsliste>]
END;
