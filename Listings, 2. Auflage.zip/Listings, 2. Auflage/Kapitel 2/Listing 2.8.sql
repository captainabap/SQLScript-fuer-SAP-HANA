-- Listing 2.8.sql
-- Unterschiedliche Typisierung von Tabellen
DECLARE lv_count INTEGER;

  lv_count = COALESCE((SELECT max(id) FROM aufgaben ), 0);
DO BEGIN
-- Typ einer DB-Tabelle
   DECLARE lt_tab1 aufgaben; 
-- Typ eines Tabellentyps
   DECLARE lt_tab2 id_text; 
-- Im Code mit TABLE definierter Tabellentyp 
   DECLARE lt_tab3 TABLE( id   INT, 
                          col1 NVARCHAR(12) );
   lt_tab1 = SELECT * FROM aufgaben;
   lt_tab2 = SELECT id, titel AS text FROM :lt_tab1;
   lt_tab3 = SELECT id, titel AS col1 FROM :lt_tab1;
   SELECT * FROM :lt_tab1;
   SELECT * FROM :lt_tab2;
   SELECT * FROM :lt_tab3;
END;
