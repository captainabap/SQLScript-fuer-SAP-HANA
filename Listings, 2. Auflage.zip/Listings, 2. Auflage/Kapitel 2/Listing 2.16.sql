-- Listing 2.16.sql
-- Syntax von anonymen Blöcken
DO [(<Parameter>)]
BEGIN
   [<Deklarationen>]
   [<Ausnahmebehandler>]
   [<Anweisungsliste>]
END;
