-- Listing 2.35.sql
-- Zugriff auf die Komponenten einer UDL
CREATE LIBRARY testlib
AS BEGIN
  PUBLIC VARIABLE cv_42 CONSTANT INTEGER DEFAULT 42;
  
  PUBLIC PROCEDURE proc1 (OUT ov_result INTEGER)
  AS BEGIN
    ov_result = :cv_42;
  END;
    
  PUBLIC PROCEDURE call_proc1(OUT ov_result INTEGER)
  AS BEGIN
   CALL proc1(ov_result=>ov_result);
  END;
END;

CALL testlib:call_proc1(?);
SELECT testlib:cv_42 FROM DUMMY;

DO BEGIN 
  USING testlib AS lib; --Definition des ALIAS  
  SELECT lib:cv_42 FROM DUMMY;
END;
