-- Listing 2.2.sql
-- Beispiel für unterschiedliche Formatierung
SELECT col1,col2 FROM T1;
SELECT col1,
       col2
    FROM T1 ;
