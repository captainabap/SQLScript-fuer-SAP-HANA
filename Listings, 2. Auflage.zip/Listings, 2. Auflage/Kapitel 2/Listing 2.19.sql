-- Listing 2.19.sql
-- Pflichtteil der Anweisung CREATE PROCEDURE
CREATE PROCEDURE <Prozedurname>
AS
BEGIN
  <Quellcode>
END;
