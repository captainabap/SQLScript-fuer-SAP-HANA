-- Listing 2.1.sql
-- IF-Anweisung enthält eine INSERT-Anweisung
1  IF lv_counter > 0 
2  THEN 
3     INSERT INTO farben VALUES ('Violett');
4  END IF;
