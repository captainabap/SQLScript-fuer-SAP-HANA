-- Listing 2.4.sql
-- Beispiel für die einfache Notation
SELECT id, 
       status,
       titel
       FROM aufgaben;
