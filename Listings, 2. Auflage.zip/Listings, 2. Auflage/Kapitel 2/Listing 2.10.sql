-- Listing 2.10.sql
-- Beispiel für die Verwendung der SQL-Funktion COALESCE
SELECT * FROM test_null WHERE name NOT LIKE 'P%'
                           OR name IS NULL;
SELECT * FROM test_null WHERE name NOT LIKE 'P%'
                           OR name = NULL;
5 + NULL = NULL
NULL || 'Zeichenkette' = NULL
SELECT a.id,
       COALESCE(b.nachname, 
                to_varchar(a.bearbeiter),
                '' ) AS bearbeiter
  FROM aufgaben AS a
  LEFT OUTER JOIN benutzer AS b
  ON a.bearbeiter = b.ID
