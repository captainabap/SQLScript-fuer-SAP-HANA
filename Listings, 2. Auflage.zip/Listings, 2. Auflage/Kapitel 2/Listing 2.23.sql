-- Listing 2.23.sql
-- Interner Prozeduraufruf mit Angabe des Schemas
CALL <Prozedurname> [(<Parameter>)]
DO BEGIN
   CALL jbrandeis.statustexte(iv_sprache=>'DE',
                              et_result=> lt_statustexte) ;
END;
