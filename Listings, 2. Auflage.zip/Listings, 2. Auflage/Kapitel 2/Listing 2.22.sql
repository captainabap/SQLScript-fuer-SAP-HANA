-- Listing 2.22.sql
-- Beispiel für eine Prozedur mit dem Datentyp ANY TABLE
CREATE PROCEDURE add_column(IN it_any TABLE(...), 
                            OUT ot_any TABLE(...))
AS BEGIN
  ot_any = SELECT *,
                 'New' || id AS new_column
             FROM :it_any AS it;
END;

--Aufruf in der Konsole funktioniert:
CALL add_column(benutzer, ?); 

--Aufruf in einer anderen Prozedur ist nicht erlaubt
CREATE PROCEDURE test_add_column
AS BEGIN
  lt_users = SELECT * 
               FROM benutzer;
  add_column( :lt_users, lt_tmp );

  SELECT * 
    FROM :lt_tmp;
END;
