-- Listing 2.41.sql
-- Testfälle für die Funktion UDF_GROESSENKATEGORIE
SELECT udf_groessenkategorie(30, 30, 10)  FROM dummy;
SELECT udf_groessenkategorie(35, 30, 15)  FROM dummy;
SELECT udf_groessenkategorie(30, 30, 30)  FROM dummy;
SELECT udf_groessenkategorie(121, 30, 30) FROM dummy;
