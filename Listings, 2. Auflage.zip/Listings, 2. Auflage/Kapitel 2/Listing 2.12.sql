-- Listing 2.12.sql
-- Erzeugen einer leeren Tabelle mit Hilfe von DUMMY
errorTab =  SELECT '' AS ERROR_TEXT,
                   '' AS SQL__PROCEDURE__SOURCE__RECORD
              FROM dummy 
              WHERE dummy = 'Y';
