-- Listing 2.14.sql
-- Beispiele für unterschiedliche Blöcke
--Alleinstehender Block
BEGIN 
   <Block> 
END;
--Prozedurdefinition
CREATE PROCEDURE <Prozedurname> <Parameterdefinition>
AS BEGIN 
   <Block> 
END;
--Blöcke in einer IF/ELSE Bedingung
IF <Bedingung> 
THEN 
   <Block1> 
ELSE 
   <Block2> 
END IF;
--Block in einer FOR-Schleife
FOR <Laufvariable> IN <Intervall> DO 
   <Block> 
END FOR;
--Block in einer WHILE-Schleife
WHILE <Bedingung> DO 
   <Block> 
END WHILE;
