-- Listing 3.10.sql
-- Syntax des komplexen CASE-Ausdrucks

CASE WHEN <Bedingung1> THEN <Ergebnis1>
    [WHEN <Bedingung2> THEN <Ergebnis2>
     ...]
    [ELSE <Ergebnis>]
END
