-- Listing 3.11.sql
-- Komplexe CASE-Ausdrücke zum Prüfen von unterschiedlichen Bedingungen

lt_intab_with_flags = 
     SELECT *,
            CASE WHEN stocktype IN ( 'F', 'H', 'W' ) 
                 THEN 1
                 ELSE 0 
                 END         AS is_transit_stock,
            CASE WHEN stocktype IN ( 'D', 'I', 'J' ) AND 
                      stockcat NOT IN ( 'K', 'R' ) 
                 THEN 1
                 ELSE 0 
                 END         AS is_blocked_stock,
            CASE WHEN stockcat = '' OR 
                    ( stockcat IN ( 'E', 'Q' ) AND
                      indspecstk IN ( 'A', 'M' ) ) 
                 THEN 1
                 ELSE 0 
                 END         AS is_valued_stock,
            CASE WHEN processkey IN ( '000', '001', '002', 
                                      '003', '004', '005', 
                                      '006', '007', '010' ) 
                 THEN 1
                 ELSE 0 
                 END         AS is_processkey_000_010,
            CASE WHEN processkey IN ( '000', '001', '002', 
                                      '003', '004', '005',
                                      '006', '007', '010', 
                                      '050', '051', '052' ) 
                 THEN 1
                 ELSE 0 
                 END         AS is_processkey_000_052,
            CASE WHEN processkey IN ( '100', '101', '102', 
                                      '103', '104', '105', 
                                      '106', '107', '110' ) 
                 THEN 1
                 ELSE 0 
                 END         AS is_processkey_100_110,
            CASE WHEN processkey IN ( '100', '101', '102', 
                                      '103', '104', '105',
                                      '106', '107', '110', 
                                      '150', '151', '152' ) 
                 THEN 1
                 ELSE 0 
                 END         AS is_processkey_100_152,
            CASE WHEN stockrelev = 1 
                 THEN 1
                 ELSE 0 
                 END         AS is_stockrelev
FROM :intab;
