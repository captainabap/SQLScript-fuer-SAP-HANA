-- Listing 3.15.sql
-- Berechnung des Aufwands für ein Projekt

SELECT SUM(ist_aufwand)
FROM aufgaben
WHERE projekt = 1;
