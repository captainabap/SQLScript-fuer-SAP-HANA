-- Listing 3.16.sql
-- Berechnung des Aufwands für alle Projekte

SELECT projekt,
       SUM(ist_aufwand)
FROM aufgaben
GROUP BY projekt;
