-- Listing 3.46.sql
-- Aggregation mit den Klauseln GROUP BY und HAVING

SELECT ... GROUP BY ... HAVING <Bedingung>
SELECT bearbeiter, 
       AVG(plan_aufwand)
FROM aufgaben
GROUP BY bearbeiter
HAVING count(*) > 5;
