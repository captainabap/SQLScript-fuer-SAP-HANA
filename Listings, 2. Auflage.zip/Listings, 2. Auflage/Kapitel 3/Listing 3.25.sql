-- Listing 3.25.sql
-- Eingebettete Funktion in einer SQL-Abfrage

SELECT ... FROM <Tabellenausdruck> 
SELECT * FROM viewname(wert1, wert2);
SELECT  "S1", "in_out"
FROM "system-local.private.jbrandeis/zjb_colview"
            (placeholder."$$IP_STATUS$$"=>'a');
01  CREATE PROCEDURE test_anonymous_function
02    (IN iv_max INT,
03     OUT ot_result TABLE(number INTEGER, 
04                         letter VARCHAR ) )
05  AS BEGIN
06   ot_result = 
07     SELECT number,
08            letter
09            
10     FROM 
11          SQL FUNCTION (IN iv_a INT => :iv_max)
12          RETURNS TABLE (number INT, 
13                         letter VARCHAR(1))
14          BEGIN
15            DECLARE lv_cnt INT;
16            DECLARE lv_chars VARCHAR(30)   
17                             DEFAULT 'ABCDEFGHIJKLMNOP';
18            
19            lt_result = SELECT 0   AS number,
20                               ' ' AS letter 
21                        FROM dummy 
22                        WHERE dummy <> 'X';       
23            
24            FOR lv_cnt IN 1..:iv_a DO
25            
26              lt_result = SELECT * FROM :lt_result 
27                            UNION
28                          SELECT lv_cnt AS number,
29                                 SUBSTRING(:lv_chars, 
30                                           :lv_cnt, 
31                                           1) AS letter
32                            FROM dummy;
33                            
34            END FOR;
35            
36            RETURN SELECT * FROM :lt_result;
37          END
38     WHERE MOD(number, 2) = 0 ; 
39  END;
40  
41  CALL test_anonymous_function(13, ?);
