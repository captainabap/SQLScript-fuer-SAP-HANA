-- Listing 3.2.sql
-- Syntax der Deklaration von Tabellenvariablen

DECLARE <Variablenname> 
[CONSTANT] 
TABLE( <Spaltenname> <Typ> [,...] )|<Tabellentyp> 
[{ DEFAULT | = } <Initialwert> ]
