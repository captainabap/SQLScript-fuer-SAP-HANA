-- Listing 3.17.sql
-- Aggregation mit Gruppierung über zwei Spalten

SELECT projekt,
   bearbeiter,
   SUM(ist_aufwand)
FROM aufgaben
GROUP BY projekt,
   bearbeiter
ORDER BY projekt,
   bearbeiter;
