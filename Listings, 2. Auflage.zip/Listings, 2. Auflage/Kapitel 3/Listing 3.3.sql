-- Listing 3.3.sql
-- Syntax der SELECT-Abfrage

lt_var2 = :lt_var1; --Nicht erlaubt
lt_var2 = SELECT * FROM :lt_var1; 
SELECT <SELECT-Klausel> 
  FROM-Klausel
  [WHERE <WHERE-Bedingung>]
  [GROUP BY <Gruppierung>
  [HAVING <HAVING-Bedingung>]]
  [ORDER BY <Sortierung>]
  [LIMIT <Begrenzung>]
