-- Listing 3.24.sql
-- Beispiel mit der Window Function LEAD

...ROWS BETWEEN 1 PRECEDING AND 1 FOLLOWING
SELECT id,
   projekt,
   LEAD(id) OVER ( PARTITION BY projekt 
                   ORDER BY id ) AS naechste_aufgabe
FROM aufgaben
ORDER BY id;
