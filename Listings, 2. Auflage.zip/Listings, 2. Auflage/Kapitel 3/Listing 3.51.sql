-- Listing 3.51.sql
-- Beispiele für Unterabfragen

--1. Skalare Unterabfrage
SELECT *
FROM aufgaben
WHERE status = (
      SELECT max(id)
      FROM status );

--2. Spalten-Unterabfrage
SELECT *
FROM aufgaben
WHERE status IN (
      SELECT id
      FROM status
      WHERE is_final = true );

--3. Tabellen-Unterabfrage
SELECT b.vorname || ' ' || b.Nachname AS PL,
   p.titel
FROM (
   SELECT *
   FROM projekte
   WHERE titel LIKE 'F%' ) AS p
INNER JOIN benutzer AS b
   ON p.projektleiter = b.id;
