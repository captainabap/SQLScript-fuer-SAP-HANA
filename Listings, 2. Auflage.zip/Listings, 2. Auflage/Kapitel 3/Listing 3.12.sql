-- Listing 3.12.sql
-- CASE als Ersatz für eine IF-Bedingung

CASE WHEN wert2<>0 THEN wert1/wert2
     ELSE 0
     END AS division
