-- Listing 3.26.sql
-- Syntax des Cross Join

SELECT ... 
   FROM <Tabellenausdruck1> CROSS JOIN <Tabellenausdruck2> 

SELECT ... 
   FROM <Tabellenausdruck1> , <Tabellenausdruck2> 
