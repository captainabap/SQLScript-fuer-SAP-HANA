-- Listing 3.53.sql
-- Verwendung des MAP_MERGE-Operators

"SAP_HANA_DEMO"."sap.hana.democontent.epm.data::MD.Addresses"
--Anlegen der MAP-Funktion
CREATE FUNCTION map_table_row_count(IN iv_tabname nvarchar(30))
RETURNS TABLE (tabname  NVARCHAR(30),
               rowcount INT )
AS BEGIN
    DECLARE lv_sql NVARCHAR(100);
    DECLARE lt_result TABLE( tabname  NVARCHAR(30),
                             rowcount INT );
    EXEC 'SELECT ''' 
         || :iv_tabname 
         || ''' AS tabname, '
         || 'COUNT(*) as rowcount '
         || 'FROM '
         || :iv_tabname 
         INTO lt_result;
    RETURN SELECT * FROM :lt_result;
END;

--Aufruf des MAP_MERGE Operators in einem Anonymen Block 
DO BEGIN 

  lt_table = SELECT left(table_name,30) AS tabname
               FROM m_cs_tables
              WHERE schema_name = 'SYSTEM';             
  lt_result = MAP_MERGE( :lt_table, 
                         map_table_row_count(
                                      :lt_table.tabname) );
  SELECT * FROM :lt_result;      
END;
