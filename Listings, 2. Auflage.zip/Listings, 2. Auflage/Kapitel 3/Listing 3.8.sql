-- Listing 3.8.sql
-- Syntax des einfachen CASE-Ausdrucks

CASE <Ausdruck>
   WHEN <Ausdruck1> THEN <Ergebnis1>
   [WHEN <Ausdruck2> THEN <Ergebnis2>]
   (...)
   [ELSE <Ergebnis>]
END;
