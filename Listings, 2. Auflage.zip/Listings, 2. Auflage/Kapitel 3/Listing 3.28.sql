-- Listing 3.28.sql
-- Syntax des INNER JOIN

SELECT ... 
   FROM <Tabellenausdruck1> 
   [INNER] JOIN <Tabellenausdruck2> 
      ON <Join-Bedingung>
