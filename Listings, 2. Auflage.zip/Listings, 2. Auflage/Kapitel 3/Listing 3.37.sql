-- Listing 3.37.sql
-- Beispiele für das EXISTS-Prädikat

--1. Abfrage mit EXISTS-Prädikat
--   Alle Benutzer mit mindestens einer Aufgabe
SELECT *
FROM benutzer
WHERE EXISTS (
      SELECT bearbeiter
      FROM aufgaben
      WHERE aufgaben.bearbeiter = benutzer.id );

--2. Abfrage mit NOT EXISTS
--   Aufgaben, deren Status nicht in der Statustabelle steht
SELECT *
FROM aufgaben
WHERE NOT EXISTS (
      SELECT id
      FROM status
      WHERE status.id = aufgaben.status );

--3. Analoge Abfrage mit NOT IN
SELECT *
FROM aufgaben
WHERE status NOT IN (
      SELECT id
      FROM status );
