-- Listing 3.22.sql
-- Syntax für Window Function

<Window Function> OVER ( 
   [PARTITION <Gruppierung>] 
   [ORDER BY <Sortierung>] 
   [ROWS <Ausschnitt>] ) 
