-- Listing 3.32.sql
-- Beispiele für die Verwendung von Vergleichsprädikaten

ON 1 = 1;
--1. Alle Aufgaben mit einem Status kleiner/gleich 3
SELECT *
FROM aufgaben
WHERE status <= 3;

--2. Alle Aufgaben, die im Status 1, 2 oder 4 sind
SELECT *
FROM aufgaben
WHERE status = ANY ( 1, 2, 4 );

--3. Alle Aufgaben, die in einem finalen Status sind
SELECT *
FROM aufgaben
WHERE status = ANY ( SELECT id
                     FROM status
                     WHERE is_final = true  );

--4. Alle Aufgaben, die nicht in einem finalen Status sind
SELECT *
FROM aufgaben
WHERE status <> ALL ( SELECT id
                      FROM status
                      WHERE is_final = true );
