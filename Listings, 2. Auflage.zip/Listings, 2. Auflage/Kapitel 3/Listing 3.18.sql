-- Listing 3.18.sql
-- Verkettung der Teamnamen mit der Aggregatfunktion STRING_AGG

SELECT sprache,
   STRING_AGG(team_text, ', ')
FROM team_text
GROUP BY sprache; 
