-- Listing 3.48.sql
-- Verwendung von UNION und UNION ALL

<Abfrage1> <Mengenoperator> <Abfrage2>
--Abfrage mit UNION: Duplikate werden entfernt
SELECT 'A' AS spalte1,
       'B' AS spalte2
FROM dummy
UNION
SELECT 'A' AS spalte1,
       'B' AS spalte2
FROM dummy;

--Zweite Abfrage mit UNION ALL ohne Duplikatsentfernung
SELECT 'A' AS spalte1,
       'B' AS spalte2
FROM dummy
UNION ALL
SELECT 'A' AS spalte1,
       'B' AS spalte2
FROM dummy;
