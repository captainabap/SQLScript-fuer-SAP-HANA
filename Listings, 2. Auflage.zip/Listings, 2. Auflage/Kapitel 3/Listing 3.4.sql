-- Listing 3.4.sql
-- Beispiel für die Verwendung von Aliasnamen für Spalten

SELECT * FROM procedures LIMIT 5;
SELECT * FROM procedures LIMIT 10 OFFSET 5;
SELECT DISTINCT country, city
FROM "sap.hana.democontent.epm.data::MD.Addresses"; 
SELECT Feld1, Feld2, Feld3, ...
SELECT '1' AS counter,
       "NAME.FIRST"  AS vorname,
       "NAME.LAST" AS nachname
FROM "sap.hana.democontent.epm.data::MD.Employees";
