-- Listing 3.31.sql
-- Beispiel für einen Lateral Join

SELECT b.id as bearbeiter,
       vorname, 
       nachname,
       cnt 
FROM benutzer AS b
CROSS JOIN LATERAL (SELECT COUNT(*) AS cnt,
                           bearbeiter
                    FROM aufgaben
                    WHERE bearbeiter = b.id
                    GROUP BY bearbeiter ) 
