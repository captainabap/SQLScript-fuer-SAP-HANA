-- Listing 3.9.sql
-- Beispiel für einen einfachen CASE-Ausdruck

CASE abteilung
   WHEN 'IT' THEN 'EDV Abteilung'
   WHEN 'MA' THEN 'Marketing'
   WHEN 'VT' THEN 'Vertrieb'
   ELSE abteilung
END AS "Abteilung"
