-- Listing 9.5.sql
-- Dummy-Implementierung einer Expertenroutine

METHOD GLOBAL_EXPERT BY DATABASE PROCEDURE FOR HDB LANGUAGE SQLSCRIPT 
OPTIONS READ-ONLY.
  outtab   = SELECT * FROM :outtab;
  errortab = SELECT * FROM :errortab;
ENDMETHOD.
