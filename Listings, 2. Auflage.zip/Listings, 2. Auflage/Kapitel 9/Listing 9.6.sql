-- Listing 9.6.sql
-- Expertenroutine zum Transponieren von Kennzahlen

METHOD GLOBAL_EXPERT BY DATABASE PROCEDURE 
FOR HDB LANGUAGE SQLSCRIPT OPTIONS READ-ONLY.
  lt_tmp =  SELECT *, 
                   fiscyear || '001' AS fiscper, 
                   amount_01 AS amount 
              FROM :intab 

            UNION ALL

            SELECT *, 
                   fiscyear || '002' AS fiscper, 
                   amount_02 AS amount 
              FROM :intab 

            UNION ALL

<… Für alle Perioden 1-12 einen SELECT>

            UNION ALL

            SELECT *, 
                   fiscyear || '012' AS fiscper, 
                   amount_12 AS amount 
            FROM :intab ;

--Ausgangsprojektion, um die Felder in die richtige Reihenfolge
-- zu bringen und FISCYEAR und AMOUNT_XX-Felder zu entfernen. 
  outtab = SELECT  COMPCODE,
                   ACCOUNT,
                   CURR,
                   FISCPER,
                   RECORDMODE,
                   AMOUNT,
                   RECORD,
                   SQL__PROCEDURE__SOURCE__RECORD
            FROM :lt_tmp; 

ENDMETHOD.
