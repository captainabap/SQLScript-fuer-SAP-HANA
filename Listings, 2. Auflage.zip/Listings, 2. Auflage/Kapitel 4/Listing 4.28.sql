-- Listing 4.28.sql
-- Ausgabe eines Datums als Datentyp DATE und VARCHAR

TABLE_SUMMARY(<Tabellenvariable>[, <Anzahl Zeilen>])
CREATE TABLE datum(line INT,datum DATE) ;
INSERT INTO datum VALUES(1,'1.12.2017') ;
INSERT INTO datum VALUES(2,'2017.12.02') ;
SELECT line,
       datum,
       TO_VARCHAR(datum) AS as_char
   FROM datum;
DROP TABLE datum;
