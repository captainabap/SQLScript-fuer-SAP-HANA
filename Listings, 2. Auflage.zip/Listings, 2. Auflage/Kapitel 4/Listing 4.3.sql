-- Listing 4.3.sql
-- Ermittlung der Länge von Zeichenketten

SELECT LENGTH('')               AS length_space,
       LENGTH('Peter')          AS length_peter,
       LENGTH('Jörg')           AS length_joerg,
       LENGTH(' ')             AS length_china,
       LENGTH(TO_VARCHAR(' ')) AS lenght_china_vc
FROM   dummy; 
