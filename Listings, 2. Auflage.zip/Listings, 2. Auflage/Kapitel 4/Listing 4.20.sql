-- Listing 4.20.sql
-- Konvertierung von Zeichen in ASCII bzw. Unicode und umgekehrt

SELECT ASCII('A')     AS char2ascii,
       CHAR(65)       AS asci2char,
       UNICODE(' ')  AS nchar2unicode,
       NCHAR('30908') AS unicode2nchar
   FROM dummy;
