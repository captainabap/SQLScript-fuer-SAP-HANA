-- Listing 4.13.sql
-- Syntax der SQL-Funktion REPLACE_REGEXPR()

REPLACE_REGEXPR( 
   <Muster>
   [FLAG <flag>]
   IN <Zeichenkette>
   [WITH <Ersetzung>]
   [FROM <Start>]
   [OCCURENCE <N. auftreten>] )
