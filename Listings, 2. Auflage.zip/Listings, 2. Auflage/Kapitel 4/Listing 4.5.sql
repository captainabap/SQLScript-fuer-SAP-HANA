-- Listing 4.5.sql
-- Funktionen für Groß- und Kleinschreibung

SELECT ABAP_UPPER('Jörg') AS "ABAP_* Function"     ,
       UPPER('Jörg')      AS "UPPER/LOWER Function",
       UCASE('Jörg')      AS "U/L-CASE Function"
FROM dummy
UNION
SELECT ABAP_LOWER('Jörg') AS "ABAP_* Function"     ,
       LOWER('Jörg')      AS "UPPER/LOWER Function",
       LCASE('Jörg')      AS "U/L-CASE Function"
FROM dummy;
