-- Listing 4.27.sql
-- Ergebnis des Aufrufs von Listing 4.26

