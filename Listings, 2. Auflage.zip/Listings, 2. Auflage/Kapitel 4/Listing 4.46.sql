-- Listing 4.46.sql
-- Konvertierung von ASCII-Dezimal nach VARBINARY

SELECT BINTOSTR( X'48616C6C6F2057656C74' ) FROM dummy;
CREATE COLUMN TABLE test_varbin(
                            ascii_int  INT,
                            ascii_char VARCHAR(1),
                            ascii_hex  VARBINARY(1)) ;

DO BEGIN
   DECLARE i INT;
   FOR i IN 33..127 DO
   INSERT INTO test_varbin VALUES(:i,
                                  CHAR(:i),
                                  BINTONHEX(CHAR(:i))) ;   
   END FOR;
END;

SELECT ascii_int  AS "Int",
       ascii_char AS "Char",
       ascii_hex  AS "Hex" FROM test_varbin;
DROP TABLE test_varbin;
