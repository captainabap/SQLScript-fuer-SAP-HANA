-- Listing 4.23.sql
-- Beispiel für die Tabellenfunktion SPLIT_REGEXPR_TO_TABLE

DO BEGIN
  USING SQLSCRIPT_STRING AS STRING_LIB;
  DECLARE lt_split TABLE(RESULT NVARCHAR(5000));
  
  lt_split = STRING_LIB:SPLIT_REGEXPR_TO_TABLE('ABC-DEF', 
                                           '[A-Z]-[A-Z]'); 
  SELECT * FROM :lt_split;
END;
