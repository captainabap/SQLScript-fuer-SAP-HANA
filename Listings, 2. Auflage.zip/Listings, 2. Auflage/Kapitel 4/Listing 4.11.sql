-- Listing 4.11.sql
-- Syntax der SQL-Funktion LOCATE_REGEXPR()

LOCATE_REGEXPR( 
   [START|AFTER]
   <Muster>
   [FLAG <flag>]
   IN <Zeichenkette>
   [FROM <Start>]
   [OCCURENCE <N. auftreten>]
   [GROUP <Gruppe>] )
