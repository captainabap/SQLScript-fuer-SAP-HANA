-- Listing 4.12.sql
-- Syntax der SQL-Funktion OCCURRENCES_REGEXPR()

OCCURRENCES_REGEXPR( 
   <Muster>
   [FLAG <flag>]
   IN <Zeichenkette>
   [FROM <Startposition>] )
