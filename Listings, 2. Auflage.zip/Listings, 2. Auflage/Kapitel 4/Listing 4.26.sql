-- Listing 4.26.sql
-- Beispiel für die Verwendung der Funktion TABLE_SUMMARY

DO BEGIN
  USING SQLSCRIPT_STRING AS STRING_LIB;
  DECLARE lv_string nvarchar(5000);
  lt_tasks = SELECT id,
                    titel 
             FROM aufgaben;               
  lv_string = string_lib:table_summary( :lt_tasks , 10);
  SELECT :lv_string FROM dummy;
END;
