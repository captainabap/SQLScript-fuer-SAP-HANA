-- Listing 4.25.sql
-- Formatierung einer Tabelle mit FORMAT_TO_TABLE

DO BEGIN
  USING sqlscript_string AS string_lib;

  SELECT  * 
     FROM string_lib:format_to_table(
       'Aufgabe Nr. {id} - {titel:.10}', 
       aufgaben);                    

END
