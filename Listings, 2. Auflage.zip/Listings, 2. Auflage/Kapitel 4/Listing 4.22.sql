-- Listing 4.22.sql
-- Beispiel für die Funktion SPLIT_REGEXPR

DO BEGIN
  USING SQLSCRIPT_STRING AS STRING_LIB;

  DECLARE A1 NVARCHAR(100);
  DECLARE A2 NVARCHAR(100); 
  
  (A1, A2) = STRING_LIB:SPLIT_REGEXPR('ABC-DEF', 
                                      '[A-Z]-[A-Z]'); 
    
  SELECT A1, 
         A2 FROM dummy; --('AB', 'EF')
END;
