-- Listing 4.37.sql
-- Ermittlung der Zeitzone eines SAP-HANA-Systems

SELECT * FROM timezones;
SELECT * 
   FROM m_host_information
   WHERE key LIKE '%timezone%';
