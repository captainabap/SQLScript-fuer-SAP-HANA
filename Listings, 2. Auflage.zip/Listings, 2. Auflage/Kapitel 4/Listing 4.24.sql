-- Listing 4.24.sql
-- Zeichenkettenformatierung mit FORMAT

DO BEGIN
  USING sqlscript_string AS string_lib;
  DECLARE lv_string NVARCHAR(100) ;

  lv_string = string_lib:format('{1} {0} ist {2:f} Jahre alt', 
                                'Müller', 
                                'Peter',  
                                21.3 );
  SELECT :lv_string FROM dummy;
END;
