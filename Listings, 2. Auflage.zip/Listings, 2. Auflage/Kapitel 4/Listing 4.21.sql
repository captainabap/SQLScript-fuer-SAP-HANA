-- Listing 4.21.sql
-- Beispiele für die SPLIT-Funktion

<N-Tupel> = SPLIT(<Zeichenkette>, <Trenner>[,<# Trennungen>])
DO BEGIN
  USING SQLSCRIPT_STRING AS STRING_LIB;

  DECLARE A1 NVARCHAR(100);
  DECLARE A2 NVARCHAR(100);
  DECLARE A3 NVARCHAR(100);  
  
-- Split funktioniert sauber:  
  (A1, A2, A3) = STRING_LIB:SPLIT('ABC-DEF-GHI', '-'); 
  
-- Zu wenige Abschnitte:  
  (A1, A2, A3) = STRING_LIB:SPLIT('ABC-DEF', '-'); 
  
-- Zu viele Abschnitte:  
  (A1, A2, A3) = STRING_LIB:SPLIT('ABC-DEF-GHI-JKL', '-'); 
  
-- Begrenzt auf 3 Abschnitte funktioniert:  
  (A1, A2, A3) = STRING_LIB:SPLIT('ABC-DEF-GHI-JKL', '-', 2); 
  
  SELECT A1, 
         A2,
         A3 FROM dummy;
END;
