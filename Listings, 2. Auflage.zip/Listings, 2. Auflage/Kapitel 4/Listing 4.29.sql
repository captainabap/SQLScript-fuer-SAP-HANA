-- Listing 4.29.sql
-- Erzeugung und Darstellung des leeren Datums

CREATE TABLE datum(line INT,datum DATE) ;
INSERT INTO datum VALUES(1,'0') ;
INSERT INTO datum VALUES(2,'') ;
INSERT INTO datum VALUES(3,'0000-00-00') ;
INSERT INTO datum VALUES(4,'00000000') ;--ABAP
INSERT INTO datum VALUES(5,'0001-01-01') ;
SELECT line,
       datum,
       TO_VARCHAR(datum) AS as_char,
       DAYS_BETWEEN(datum, '00001-01-10') AS Delta
   FROM datum;
DROP TABLE datum;
