-- Listing 4.7.sql
-- Zeichenkettenzerlegung mit SUBSTR_BEFORE und SUBSTR_AFTER

SELECT SUBSTR_BEFORE('Raus aus dem Haus','aus') AS  links ,
       SUBSTR_AFTER('Raus aus dem Haus','aus')  AS  rechts,
       SUBSTR_AFTER('Raus aus dem Haus','')     AS  alles ,
       SUBSTR_AFTER('Raus aus dem Haus','ABC')  AS  nichts
   FROM
      dummy;
