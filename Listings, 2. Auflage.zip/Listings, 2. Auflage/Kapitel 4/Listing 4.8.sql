-- Listing 4.8.sql
-- SQL-Funktion SUBSTR_REGEXPR()

SUBSTR_REGEXPR( 
   <Muster>
   [FLAG <flag>]
   IN <Zeichenkette>
   [FROM <Start>]
   [OCCURENCE <N. auftreten>]
   [GROUP <Gruppe>])
