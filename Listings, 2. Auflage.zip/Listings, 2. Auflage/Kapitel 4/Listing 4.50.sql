-- Listing 4.50.sql
-- Zerlegung von Wörtern in Buchstaben mit Hilfe der SERIES-Funktionen

CREATE TYPE tt_word AS TABLE( word nvarchar(30) );

CREATE FUNCTION word2char( it_word tt_word )
            RETURNS TABLE (val nvarchar(1))
AS BEGIN
  lt_tmp = SELECT words.word,
                  pos.element_number AS pos
           FROM :it_word AS words
           CROSS JOIN SERIES_GENERATE_INTEGER(1, 0, 30) AS pos; 

  lt_tmp2 =  SELECT SUBSTR(word, pos, 1) AS val
             FROM :lt_tmp;
               
  RETURN SELECT * FROM :lt_tmp2 
         WHERE val <> '';
END;

--Aufruf der Funktion
DO BEGIN
  lt_vornamen = SELECT vorname AS word
                     FROM benutzer;
  SELECT count(*), 
         val 
    FROM word2char( it_word => :lt_vornamen )
    GROUP BY val
    ORDER BY COUNT(*) DESC;
END;
