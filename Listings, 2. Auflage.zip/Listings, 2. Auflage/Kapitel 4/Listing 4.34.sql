-- Listing 4.34.sql
-- Unterschiede zwischen den SQL-Funktionen ADD_MONTHS() und ADD_MONTHS_LAST()

SELECT CURRENT_DATE FROM dummy;
SELECT  ADD_MONTHS('2017-01-31',1) FROM dummy; --> 28.02.2017
SELECT  ADD_MONTHS_LAST('2017-02-28', 1) FROM dummy; 
                          --> 31.03.2017 
SELECT  ADD_MONTHS('2017-02-28', 1) FROM dummy; 
                          --> 28.03.2017
