-- Listing 4.49.sql
-- Zeitreihe mit den Monaten des Jahres 2017

Could not execute 'select to_tinyint( 1000) from dummy'
[314]: numeric overflow: 1000 at function to_tinyint() 
SELECT * FROM SERIES_GENERATE_INTEGER( 2, 3, 20);
SELECT * FROM SERIES_GENERATE_DATE( 'INTERVAL 1 MONTH', 
                                    date'2019-01-01', 
                                    date'2020-01-01');
