-- Listing 11.3.sql
-- Testbibliothek

CREATE LIBRARY test_demo_dm 
LANGUAGE SQLSCRIPT TEST 
AS BEGIN 

  @test()
  PUBLIC PROCEDURE t_aufgaben_cnt 
  AS BEGIN
    USING sqlscript_test AS test;
    test:expect_eq((SELECT COUNT(*) FROM aufgaben),
                     1000 );
  END;    
END;
