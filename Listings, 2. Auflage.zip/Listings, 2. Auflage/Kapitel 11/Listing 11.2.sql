-- Listing 11.2.sql
-- Beispiel für die Nutzung der Logging-Bibliothek

CREATE TABLE mylog LIKE sys.sqlscript_logging_table_type;
CREATE PROCEDURE do_something (IN iv_text nvarchar(15) ) 
READS SQL DATA
AS BEGIN
  USING sqlscript_logging AS logger;
    logger:log(logger:level_debug, 
               'c1', 
               'Procedure parameter: ' || :iv_text );
END;

CREATE TABLE mylog LIKE sys.sqlscript_logging_table_type;

DO BEGIN
  USING sqlscript_logging AS logger;
    logger:create_configuration('c1');
    logger:add_sqlscript_object('c1', 
                                current_schema, 
                                'DO_SOMETHING');
    logger:set_output_table('c1', 
                            current_schema, 
                            'MYLOG');
    logger:set_level('c1', 'debug');
    logger:start_logging('c1');
   
    do_something( 'Hello Log!' );
END;    

SELECT * FROM mylog;  
