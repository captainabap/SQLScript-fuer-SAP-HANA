-- Listing 11.4.sql
-- Auslagern der Tests in eine private Prozedur

CALL SQLSCRIPT_RUN_TESTS_ON_ORIGINAL_DATA('{"schema":"SYSTEM",
                          "library":"TEST_DEMO_DM"}', ?, ?, ?);
CREATE LIBRARY TEST_DEMO_DM 
LANGUAGE SQLSCRIPT TEST 
AS BEGIN 
  
  PRIVATE PROCEDURE check_table_count
    (IN iv_tabname NVARCHAR(30),
     IN iv_expected_count INTEGER)
  AS BEGIN
    USING sqlscript_test AS test;
    DECLARE lv_query NVARCHAR(5000);
    DECLARE lv_count INTEGER;
    
    lv_query = 'SELECT COUNT(*) FROM ' || :iv_tabname;
    EXEC lv_query INTO lv_count;
    test:expect_eq( :lv_count, :iv_expected_count );
      
  END;
  
  @test()
  PUBLIC PROCEDURE t_table_count 
  AS BEGIN
      check_table_count( 'AUFGABEN', 1000);
      check_table_count( 'BENUTZER', 30);
      check_table_count( 'STATUS', 6); 
      check_table_count( 'STATUS_TEXT', 12);
    --check_table_count( 'STATUS_TEXT', 13);
  END;     
END;
