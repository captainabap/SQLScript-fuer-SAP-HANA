-- Listing 10.6.sql
-- Beispiel f�r Kurzformen in SQLScript
SELECT * 
FROM farben groessen;

SELECT * 
FROM farben, groessen;
