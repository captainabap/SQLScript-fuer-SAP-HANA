-- Listing 5.6.sql
-- Beispiel f�r eine einfache UPDATE-Anweisung
 
UPDATE tabelle_2 
   SET wert1 = 'Aktualisiert',
       wert2 = 'Zeile ' || key1
   WHERE key1 < 300;
